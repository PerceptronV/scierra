# Scierra
_a **S**imulated **C**++ **I**nt**ER**preter with **R**ecurrent **A**daptation_

Scierra is a Python package that makes use of the GCC CLI to simulate an interpreted C++ environment.
